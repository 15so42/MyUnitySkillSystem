namespace MySkillSystem
{
    public enum ErrorType
    {
        Success,
        Failure,
    }
    public class ErrorCode 
    {
        public ErrorType code;
        public string errorStr;

        public ErrorCode(ErrorType code, string errorStr)
        {
            this.code = code;
            this.errorStr = errorStr;
        }
    }
}