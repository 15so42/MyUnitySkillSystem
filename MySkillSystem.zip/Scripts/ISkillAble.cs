using UnityEngine;

namespace MySkillSystem
{
    public interface ISkillAble
    {
        public bool AddSkillCheck(string skillName);

        public ErrorCode AddSkill(SkillBase skillBase);

        public ErrorCode AddSkill(SkillItemUi skillItemUI);

        public void LogTip(string msg);

        public GameObject GetObj();
    }
}
