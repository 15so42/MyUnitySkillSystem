using System.Collections.Generic;
using UnityEngine;

namespace MySkillSystem
{
    public class SkillFxManager : MonoBehaviour
    {
        [System.Serializable]
        public struct FxConfigPair
        {
            public SkillFxType skillFxType;
            public GameObject fxGo;
        }
        public enum SkillFxType
        {
            Fire,
            Poison,
        
        }

        public List<KeyValuePair<SkillFxType, GameObject>> fxConfigPairs = new List<KeyValuePair<SkillFxType, GameObject>>();
    
        public static SkillFxManager instance;
        public void Awake()
        {
            instance = this;
        }

        // Start is called before the first frame update
        void Start()
        {
        
        }

        // Update is called once per frame
        void Update()
        {
        
        }


        public void GetObjBySkillFxType(SkillFxType skillFxType)
        {
            //return fxConfigPair.Find(x => x.Key == skillFxType).Value;
        }
    
        public GameObject[] AddFxToMesh(MeshRenderer[] meshRenderers,SkillFxType fxType)
        {
            GameObject[] ret=new GameObject[meshRenderers.Length];
            foreach (var meshRenderer in meshRenderers)
            {
            
            }

            return ret;
        }

        public void DestroyFxs(GameObject[] gos)
        {
            foreach (var go in gos)
            {
                Destroy(go);
            }
        }
    }
}
