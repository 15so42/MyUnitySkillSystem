﻿using System;
using UnityEngine;

namespace MySkillSystem
{
    public abstract class SkillBase : ScriptableObject
    {

    
        [HideInInspector]public ISkillAble createCommander;
        [HideInInspector] public ISkillAble useCommander;
    
    
    
        [Header("描述")]
        public string desc="无描述";
    
    
    
        public string skillName;
        public Sprite icon;
    
    
        public int cd;//冷却时间
        [HideInInspector]public float timer = 0;

        [Header("可使用次数,-1表示无限次")]
        public int life=-1;

        private int maxLife;

        public bool autoLife=true;

        [Header("可堆叠层数")] public int maxStackCount = 1;
        public int stackCount;
        [Header("被动技能，就绪后无需等待命令直接Act")]
        public bool passive;

        [HideInInspector]public ISkillAble owner;
        [HideInInspector]public bool ready = true;//主动技能是否准备完成
        [HideInInspector]public bool finished = false;//技能是否完成,SkillContainer自动清除已经完成的技能和buff

   
        
        //事件
        public Action onFinished;
        public Action<int> onLifeChangedAction;
        public Action<int> onStackChangedAction;
        public Action onKilled;
        public Action onDestroy;
        public virtual void Init(ISkillAble target,ISkillAble creator)
        {
            BaseInit();
            this.owner = target;//owner,target表示Skill作用的对象
            this.createCommander = creator;//Skill的创造者，敌人或者自己。

        }

        //添加给Obj执行的技能，不需要ISkillAble，直接通过SkillContainer执行，部分特殊的情况下才会用到
        public virtual void Init(SkillContainer skillContainer,ISkillAble creator)
        {
            BaseInit();
            
            this.createCommander = creator;
        }

        private void OnEnable()
        {
            skillName = name;
        }

        void BaseInit()
        {
            timer = cd;
            onLifeChangedAction += OnLifeChanged;//计算剩余次数
            
            maxLife = life;
        }

        public void ResetTimer()
        {
            timer = cd;
        }

        //上层调用，主动释放
        public virtual bool Use()
        {
            var errCode = PlayCheck();
            if (errCode == null || errCode.code == ErrorType.Success)
            {
                return true;
            }
        
            owner.LogTip(errCode.errorStr);
            return false;
        }

        public void ChangeLife(int newLife)
        {
            life = newLife;
            onLifeChangedAction?.Invoke(newLife);
        }
        public virtual ErrorCode PlayCheck()
        {
            if(finished)
                return null;
        
            if(!ready)
                return new ErrorCode(ErrorType.Failure,"技能尚未准备好");
            Play();
            if (autoLife)
            {
                ChangeLife(--life);
            }

        
        
            return new ErrorCode(ErrorType.Success,"成功");
        }

        public void OnLifeChanged(int life)
        {
            if (life == 0)
            {
                onFinished?.Invoke();
                finished = true;
            }
            else
            {
                timer = cd;//重置冷却时间
            
            }
        }

   
    

        public float GetLeftCdRatio()
        {
            return (float) timer / cd;
        }

        protected virtual void Play()
        {
        
        }

        public virtual void Update()
        {
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                ready = true;
                if (passive)//被动技能直接释放
                {
                    PlayCheck();
                }
            
            }
        }

        public virtual void Kill()
        {
            onKilled?.Invoke();
            Destroy(this);
        }

        public void OnDestroy()
        {
            onDestroy?.Invoke();
        }

        public void AddStackCount()
        {
            stackCount++;
            if (stackCount > maxStackCount)
            {
                stackCount = maxStackCount;
            }
            onStackChangedAction?.Invoke(stackCount);
        }

        public virtual void Refresh()
        {
            //刷新
            //timer = cd;
            life = maxLife;
        }

    }
}