﻿using System.Collections.Generic;
using UnityEngine;

namespace MySkillSystem
{
    public class SkillContainer : MonoBehaviour
    {
        public List<SkillBase> skills=new List<SkillBase>();
    
        public ISkillAble owner;
        public void Init(ISkillAble owner)
        {
            this.owner = owner;
        
        }
    
        /// <summary>
        /// true 表示可新加，否则可能是刷新持续事件或者增加堆叠层数
        /// </summary>
        /// <param name="skillName"></param>
        /// <returns></returns>
        public virtual bool AddSkillCheck(string skillName)
        {
     
            for (int i = 0; i < skills.Count; i++)//相同效果会直接重置
            {
                if (skills[i].skillName == skillName)
                {
                    //判断技能层数
                    if (skills[i].maxStackCount > 1)
                    {
                        skills[i].AddStackCount();
                    }
                    skills[i].Refresh();
                
                    return false;
                }
            }
        
            return true;
        }

        public bool UseSkill(int index)
        {
        
            ErrorCode errCode = null;
            skills[index].useCommander = owner;//技能以使用者为主人
            if(skills[index].passive==false)//主动技能
                errCode=skills[index].PlayCheck();
            else//被动技能
            {
                return false;
            }
        
            if(errCode!=null && errCode.code!=ErrorType.Success)
                return false;

        
            return true;

        }



        public void AddSkill(SkillBase skillBase)
        {
            skills.Add(skillBase);
        }

    
        private void Update()
        {
       
            for (int i = 0; i < skills.Count; i++)
            {
                if (!skills[i] || skills[i].finished)
                {
                    skills.RemoveAt(i);
                    i--;
                }
                else
                {
                    skills[i].Update();
                
                }
            }
            //删除无用技能，对技能重新排序
            SortSkill();
        
        
        }

        public void SortSkill()
        {
        
        }

        public void RemoveSkill(int index)
        {
            skills[index].Kill();
        
            skills.RemoveAt(index);
        }
    }
}