using TMPro;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace MySkillSystem
{
    public class SkillItemUi : MonoBehaviour
    {
        public TMP_Text skillName;
   
    
        public Image icon;

        public Image fill;
        public TMP_Text lifeCount;

        public TMP_Text stackCountText;

        public SkillBase skillBase;

        private Timer showDescTimer;
        public void Init(SkillBase skillBase)
        {
            this.skillName.text = skillBase.skillName+"";
            this.skillBase = skillBase;
            icon.sprite = skillBase.icon;
            lifeCount.text = this.skillBase.life+"";
            fill.fillAmount = 1;
        
            skillBase.onFinished += OnFinished;//技能完毕事件，技能使用完后对应Ui自毁
            skillBase.onLifeChangedAction += OnLifeChanged;
            skillBase.onKilled += OnKilled;
            skillBase.onStackChangedAction += OnStackChanged;
        }

        public void ShowSkillDesc()
        {
            var lastText = this.skillName.text;//记录之前的文字
            this.skillName.text = this.skillBase.desc;
            showDescTimer=Timer.Register(6, () =>
            {
                this.skillName.text = lastText;
            });
        }

   

        private void Update()
        {
            this.fill.fillAmount = skillBase.GetLeftCdRatio();
        }

    
  

        void OnFinished()
        {
            if(gameObject)
                Destroy(gameObject);
        
        }

        public void Kill()
        {
            Destroy(gameObject);
        }

        public void OnKilled()
        {
            Kill();
        }

        public void OnStackChanged(int count)
        {
            stackCountText.text = count.ToString();
        }

        void OnLifeChanged(int life)
        {
            if (life < 0)
            {
                lifeCount.text = "";
                return;
            }
            lifeCount.text = life.ToString();
        }

        private void OnDisable()
        {
            showDescTimer?.Cancel();
            skillBase.onFinished -= OnFinished;//技能完毕事件，技能使用完后对应Ui自毁
            skillBase.onKilled -= OnKilled;
            skillBase.onStackChangedAction -= OnStackChanged;
            skillBase.onLifeChangedAction -= OnLifeChanged;
        }
    }
}