using System.Collections;
using System.Collections.Generic;
using MySkillSystem;
using UnityEngine;

/// <summary>
/// 毒技能示例，
/// </summary>
[CreateAssetMenu(fileName = "Skill/Poison",menuName = "Skill/Poison")]
public class PoisonSkill : SkillBase
{
    
    private IAttackAble attacker;
    private int damageValue=1;

    private IvictimAble self;

    public void SetAttacker(IAttackAble entity)
    {
        this.attacker = entity;
    }

    public void SetAttackDamage(int damage)
    {
        this.damageValue = damage;
    }
    
    public override void Init(ISkillAble owner,ISkillAble creator)
    {
        base.Init(owner,creator);
        if(owner==null)
            return;
        SetAttacker(creator.GetObj().GetComponent<IAttackAble>());

        self = owner.GetObj().GetComponent<IvictimAble>();

        var fx = SkillFxManager.instance.AddFxToMesh(owner.GetObj().GetComponentsInChildren<MeshRenderer>(),SkillFxManager.SkillFxType.Poison);
        onDestroy += () =>
        {
            SkillFxManager.instance.DestroyFxs(fx);

        };

    }

   

    protected override void Play()
    {
        base.Play();
        // owner.OnAttacked(new AttackInfo(attacker,AttackType.Real, damageValue));
        // createCommander.attackOtherDamage += damageValue;
        AttackManager.instance.Attack(self,new DamageInfo(attacker,self,damageValue,DamageMethod.Posion,DamageType.Real));
    }

}